# Codex 额度恢复自动续跑：上传 GitHub 与部署步骤

本文专门针对刚刚制作的 Windows 程序“Codex 额度恢复自动续跑”。上传 GitHub 用于保存源码、提供 EXE 下载；监测程序仍需在你自己的 Windows 电脑上运行。

## 1. 先区分本机使用和公开发布

| 场景 | 使用什么 |
| --- | --- |
| 你现在这台电脑直接使用 | 桌面上的 `Codex自动续跑.exe`，已配置本机调用方对话。 |
| 上传项目源码到 GitHub | 解压 `CodexQuotaMonitor-source.zip`，上传里面的源码文件。 |
| 给其他人下载 Windows 程序 | 在 GitHub Releases 中上传 `发布文件/Codex自动续跑.exe`，这是去除本机对话 ID 的发布版。 |

不要直接上传整个开发目录。它包含构建工具、测试文件夹、运行日志，以及原本针对这台电脑填写的配置。准备好的源码包只保留程序、测试、配置模板和说明。原桌面 EXE 保持原样。

## 2. 用浏览器上传源码到 GitHub

1. 登录自己的 GitHub 账号，打开 [新建仓库页面](https://github.com/new)。
2. **Owner** 选自己的账号，**Repository name** 填 `codex-quota-monitor`。
3. **Description** 可填：`Windows 上的 Codex 额度恢复自动续跑工具，支持图形界面启停。`
4. 想让任何人查看选 **Public**；只供自己或指定成员查看选 **Private**。
5. 先不勾选自动生成 README、.gitignore 和 License，因为源码包里已有前两项；许可由你自行决定。
6. 点击 **Create repository**。这些字段和流程见 [GitHub 创建仓库说明](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)。
7. 在电脑上解压 `CodexQuotaMonitor-source.zip`，进入解压后的文件夹。
8. 空仓库首页点击 **uploading an existing file**；已有文件的仓库点击 **Add file → Upload files**。
9. 把解压文件夹**里面的源码文件**拖进上传区。不要只拖 ZIP，也不要把整个外层文件夹拖进去；这样 `README.md` 和 `monitor.py` 会出现在仓库根目录。
10. 提交说明填 `Initial release of Codex quota monitor`。新建的个人仓库可提交到默认分支 `main`。点击 **Commit changes**；如果选择了新分支并出现 **Propose changes**，再创建并合并 Pull Request。上传界面操作见 [GitHub 上传文件说明](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。
11. 返回仓库主页，确认能看到 `README.md`、`monitor.py`、`desktop_app.py`、`config.example.json` 和测试文件。

网页单次可以上传最多 100 个文件，单个文件最多 25 MiB；这个源码包远低于限制。[GitHub 上传限制](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)

## 3. 发布可下载的 EXE

1. 上传源码成功后，进入仓库右侧的 **Releases**。
2. 点击 **Draft a new release**，首次发布也可能显示 **Create a new release**。
3. **Choose a tag** 输入 `v1.1.0`，创建该标签；**Target** 选 `main`。
4. **Release title** 填 `Codex 自动续跑 v1.1.0`。
5. 发布说明可以直接使用下面的文字：

   > Windows 图形界面，支持打开和关闭额度监测。额度恢复后自动向因额度不足而失败的本地 Codex 对话发送 continue。首次使用需按部署说明填写本机对话 ID，并保持 Codex 桌面应用开启。

6. 在附件上传区拖入 **发布文件** 文件夹中的 `Codex自动续跑.exe`，以及 `DEPLOYMENT.md`。不要上传已经针对本机配置的桌面 EXE。
7. 等待附件上传完成，点击 **Publish release**。
8. 打开 Release 页面，在 **Assets** 中确认 EXE 可下载。GitHub 自动生成的 **Source code (zip)** 是源码，不是 Windows EXE。

这些标签、附件和发布按钮的操作见 [GitHub Releases 官方说明](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)。发布说明和文件没有添加额外作者署名；网页提交归属于你登录的账号。

## 4. 在你现在这台电脑上使用

1. 打开 Codex 桌面应用，并保持登录。
2. 双击桌面的 `Codex自动续跑.exe`。
3. 点击 **打开监测**。正常连接后，窗口显示剩余额度、重置时间和运行记录。
4. 电脑保持运行，Codex 保持开启。默认每 60 秒检查一次。
5. 点击 **关闭监测** 停止；关闭窗口也会停止。

本机已有所需环境，无需重新安装 Python 或 Node.js。当前配置文件是 `%LOCALAPPDATA%\CodexQuotaMonitor\config.json`，日志与发送记录位于同目录的 `runtime` 子文件夹。

## 5. 在另一台 Windows 电脑上部署发布版

1. 准备 Windows x64 电脑。当前成品已在 Windows 11 x64 上验证。
2. 安装并登录可运行本地 Codex 对话的桌面应用，保持开启。安装入口以 [OpenAI 桌面应用快速开始](https://learn.chatgpt.com/docs/quickstart) 为准。
3. 从 [Node.js 官方下载页](https://nodejs.org/en/download) 安装 Windows LTS 版本，保留添加到 PATH 的选项。安装后打开新的 PowerShell，运行 `node --version` 确认能找到 Node.js。
4. 从 GitHub **Releases → Assets** 下载发布版 `Codex自动续跑.exe`，放到桌面。EXE 已内置 Python，运行它不需要另外安装 Python。
5. 双击一次 EXE，然后关闭窗口。首次打开会生成 `%LOCALAPPDATA%\CodexQuotaMonitor\config.json`，默认监测关闭。
6. 在该电脑的 Codex 中建立一个本地对话，明确授权自动续跑，例如：`我授权本机额度监测程序在额度恢复后向额度中断的本地 Codex 对话发送 continue，请告诉我当前对话的实际 thread ID。` 获取实际 ID，并保留这个对话可访问。这里需要对话 ID，不是标题，也不是 GitHub 仓库名。
7. 按 **Win+R**，输入 `%LOCALAPPDATA%\CodexQuotaMonitor`，打开文件夹，用记事本打开 `config.json`。
8. 将 `caller_thread_id` 的 `YOUR_CODEX_THREAD_ID` 替换为刚刚得到的真实 ID。保持 JSON 中的双引号、逗号和方括号格式正确，然后保存。
9. 如果只希望续跑某几个对话，把它们的真实 ID 放进 `thread_ids`。例如：`"thread_ids": ["第一个真实对话ID", "第二个真实对话ID"]`。空数组 `[]` 表示最近 50 个非置顶本地对话及全部置顶本地对话。
10. 重新打开 EXE，点击 **打开监测**。日志出现“已连接 Codex 桌面应用”，并显示额度，说明连接成功。

这一步的对话 ID 填写方式是本工具的配置流程；桌面本地 MCP 桥接随 Codex 版本变化，其他版本或机器仍需以日志确认兼容性。工具不会创建新的 Codex 对话，也不需要 API Key。

## 6. 从源码运行或重新打包

源码方式额外需要 Python 3.10+。解压源码包，在解压目录中打开 PowerShell：

```powershell
Copy-Item -LiteralPath .\config.example.json -Destination .\config.json
notepad .\config.json
```

填写真实的 `caller_thread_id`，保存后先只读预演：

```powershell
python .\monitor.py --dry-run --once
```

确认连接和额度查询成功后，运行：

```powershell
python .\monitor.py
```

按 **Ctrl+C** 停止。GUI 源码方式先运行 `python .\desktop_app.py`，按第 5 节填写其生成的用户配置，再点击打开。

要重新生成单文件 EXE：

```powershell
python -m unittest discover -s . -p 'test_*.py' -q
python -m pip install --target .\.build-tools pyinstaller
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build_exe.ps1
```

产物为 `dist\CodexQuotaMonitor.exe`。可重命名成 `Codex自动续跑.exe` 后放到桌面。打包采用 PyInstaller 的单文件窗口模式。[PyInstaller 官方使用说明](https://pyinstaller.org/en/stable/usage.html)

公开源码中的默认 ID 保持为占位符；本机真实 ID 只写入不上传的 `config.json` 或用户配置目录。不要把真实 ID 改进 `monitor.py` 再构建公开版。

## 7. 使用中的常见问题

| 现象 | 处理 |
| --- | --- |
| 显示“等待连接” | 确认 Codex 开启、已登录，Node.js 可用，调用方对话 ID 正确且仍可访问。点击查看日志查具体错误。 |
| 短周期已经恢复，仍不续跑 | 检查长周期额度；两个周期都可用才会续跑。重置时间只是预计时间，实际是否恢复以查询结果为准。 |
| 没有发现中断对话 | 只认最后一轮的额度失败。普通失败、手动停止、正常完成、正在执行或等待审批的对话不会续跑。超过最近 50 条的旧对话可写进 `thread_ids`。 |
| 提示已有程序运行 | 检查是否同时启动了 EXE 和源码脚本；两者共享运行锁，只保留一个。 |
| 记录显示发送结果不明 | 先关闭监测，检查原对话是否收到 continue。确认没有收到后，再把 `runtime/state.json` 中对应记录的 `status` 改回 `pending`。 |
| 关闭时显示“正在关闭” | 等待当前本地请求结束，期间不再提交新的续跑消息。 |
| 换电脑后不能直接使用 | 使用发布版并按第 5 节填写该电脑的真实对话 ID；不要复制旧电脑的发送状态文件。 |

电脑休眠、关机或 Codex 关闭期间不能监测。GitHub 仓库本身不会替你的电脑运行额度监测；当前项目没有配置自动开机启动。
