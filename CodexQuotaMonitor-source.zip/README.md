# Codex 额度恢复自动续跑

Windows 图形界面工具，查询 Codex 额度，额度恢复后向最后一轮因额度耗尽而失败的本地对话发送 `continue`。

- **打开监测 / 关闭监测** 按钮；默认关闭，关闭窗口也停止。
- 显示短周期与长周期剩余额度、重置时间和运行记录。
- 重新查询实际额度、避免重复发送、只恢复额度失败的轮次。
- 支持最近 50 个非置顶本地对话及全部置顶对话；可指定要监测的旧对话。

下载 Windows 程序请进入本仓库的 **Releases → Assets**。

## 首次使用

1. 保持 Codex 桌面应用开启并登录，安装 Windows LTS 版 Node.js。
2. 下载并打开 EXE，再关闭窗口，以生成用户配置。EXE 内置 Python。
3. 编辑 `%LOCALAPPDATA%\CodexQuotaMonitor\config.json`，将 `caller_thread_id` 替换为本机已授权自动续跑的实际 Codex 对话 ID。
4. 再次打开 EXE，点击 **打开监测**。

详细安装、配置、GitHub 上传与打包操作见 [部署步骤](DEPLOYMENT.md)。

## 源码运行

Python 3.10+：复制 `config.example.json` 为 `config.json` 并填写本机对话 ID。

```powershell
python monitor.py --dry-run --once
python monitor.py
```

图形界面源码：`python desktop_app.py`。源码监测和 EXE 共享用户目录中的运行锁与发送记录。

## 构建与测试

```powershell
python -m unittest discover -s . -p 'test_*.py' -q
python -m pip install --target .\.build-tools pyinstaller
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build_exe.ps1
```

## 使用范围

仅支持兼容本地 MCP 桥接的 Windows Codex 对话；云端对话、远程主机、正常完成、手动停止及普通网络错误不自动续跑。独立模型额度桶需配置正确的 `limit_id` 和对话范围。

电脑与 Codex 必须保持运行。桥接接口可能随桌面应用版本变化；不兼容时记录错误并等待。源码不含登录凭据、真实对话 ID 或运行日志。
