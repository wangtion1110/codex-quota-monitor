param(
    [switch]$Background,
    [switch]$DryRun,
    [switch]$Once
)
$ErrorActionPreference = 'Stop'
$monitorScript = Join-Path $PSScriptRoot 'monitor.py'
$pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
if (-not $pythonCommand) { throw 'Python 3.10+ is required. Install Python and add it to PATH.' }
$monitorArguments = @('"' + $monitorScript + '"')
if ($DryRun) { $monitorArguments += '--dry-run' }
if ($Once) { $monitorArguments += '--once' }
if ($Background) {
    $monitorProcess = Start-Process -FilePath $pythonCommand.Source -ArgumentList $monitorArguments -WindowStyle Hidden -PassThru
    Write-Host "Monitor launched (PID $($monitorProcess.Id)). See runtime\monitor.log for status."
} else {
    $foregroundArguments = @($monitorScript)
    if ($DryRun) { $foregroundArguments += '--dry-run' }
    if ($Once) { $foregroundArguments += '--once' }
    & $pythonCommand.Source @foregroundArguments
    exit $LASTEXITCODE
}
