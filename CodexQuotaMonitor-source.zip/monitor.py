"""Resume quota-failed Codex desktop chats through its bundled MCP adapter.

No API keys, UI coordinates, or third-party Python packages are required.
The desktop bridge is version-dependent; fail closed when it is unavailable.
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import os
from pathlib import Path
import queue
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger("quota-monitor")
REQUIRED_TOOLS = {"get_usage_limits", "list_threads", "read_thread", "send_message_to_thread"}


def runtime_directory():
    """Share the lock and delivery history between the EXE and script entry points."""
    return Path(os.getenv("LOCALAPPDATA", str(Path.home() / ".local/share"))) / "CodexQuotaMonitor" / "runtime"


DEFAULTS = {
    "caller_thread_id": "YOUR_CODEX_THREAD_ID",
    "poll_seconds": 60,
    "limit_id": "codex",
    "thread_ids": [],
    "exclude_thread_ids": [],
    "max_resumes_per_cycle": 1,
    "retry_seconds": 300,
    "max_send_attempts": 3,
    "node_path": "",
    "server_path": "",
    "pipe_path": "",
}


class BridgeError(RuntimeError):
    """A definite rejection: the host returned an error response."""


class UncertainDelivery(RuntimeError):
    """Transport failed; a mutating request may already have reached the host."""


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


class InstanceLock:
    def __init__(self, path):
        self.file = None
        try:
            self.file = open(path, "a+b")
            self.file.seek(0)
            if not self.file.read(1):
                self.file.write(b"0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            if self.file:
                self.file.close()
            raise RuntimeError("无法取得监测锁，可能已有监测脚本在运行。") from None

    def close(self):
        self.file.close()


class McpBridge:
    def __init__(self, node, server, pipe, caller):
        self.caller = caller
        self.responses = queue.Queue()
        self.next_id = 0
        env = os.environ.copy()
        env["CODEX_APP_TOOLS_PIPE_PATH"] = pipe
        env["CODEX_APP_TOOLS_DEFERRED"] = "0"
        self.process = subprocess.Popen(
            [node, str(server)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", env=env,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        try:
            for line in self.process.stdout:
                self.responses.put(json.loads(line))
        except (ValueError, OSError):
            pass
        finally:
            self.responses.put(None)

    def _write(self, message):
        try:
            self.process.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
            self.process.stdin.flush()
        except (OSError, ValueError):
            raise UncertainDelivery("Codex 本地连接已断开") from None

    def request(self, method, params, timeout=30):
        self.next_id += 1
        request_id = self.next_id
        self._write({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
        deadline = time.monotonic() + timeout
        while True:
            try:
                response = self.responses.get(timeout=max(0.01, deadline - time.monotonic()))
            except queue.Empty:
                raise UncertainDelivery("Codex 本地服务响应超时") from None
            if response is None:
                raise UncertainDelivery("Codex 本地连接已断开")
            if response.get("id") != request_id:
                continue
            if "error" in response:
                raise BridgeError(str(response["error"].get("message", "MCP 调用失败")))
            return response.get("result", {})

    def initialize(self):
        self.request("initialize", {
            "protocolVersion": "2024-11-05", "capabilities": {},
            "clientInfo": {"name": "codex-quota-monitor", "version": "1.0.0"},
        }, timeout=5)
        self._write({"jsonrpc": "2.0", "method": "notifications/initialized"})
        catalog = self.request("tools/list", {}, timeout=5)
        names = {tool["name"] for tool in catalog.get("tools", [])}
        if not REQUIRED_TOOLS <= names:
            raise BridgeError("本地服务不支持所需的 Codex 对话/额度工具")

    def call(self, name, arguments):
        result = self.request("tools/call", {
            "name": name, "arguments": arguments, "_meta": {"threadId": self.caller},
        })
        texts = [item["text"] for item in result.get("content", []) if item.get("type") == "text"]
        if result.get("isError"):
            raise BridgeError(" ".join(texts)[:300] or "Codex 工具拒绝了请求")
        # Successful mutating tools can return a plain-text acknowledgement.
        for text in texts:
            try:
                return json.loads(text)
            except ValueError:
                continue
        return {"acknowledgement": " ".join(texts)}

    def close(self):
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        for stream in (self.process.stdin, self.process.stdout):
            if stream:
                stream.close()


def connect(config):
    node = config["node_path"] or shutil.which("node") or os.getenv("CODEX_MCP_NODE_PATH")
    if not node:
        raise RuntimeError("未找到 Node.js，请安装 Node.js 或配置 node_path。")
    if config["server_path"]:
        server = Path(config["server_path"])
    else:
        codex_dir = Path(os.getenv("CODEX_HOME", str(Path.home() / ".codex")))
        servers = list((codex_dir / "plugins/cache/openai-bundled/codex-app-tools").glob("*/server.mjs"))
        if not servers:
            raise RuntimeError("未找到 Codex 自带的 codex-app-tools/server.mjs。")
        server = max(servers, key=lambda p: p.stat().st_mtime)
    pipes = [config["pipe_path"], os.getenv("CODEX_APP_TOOLS_PIPE_PATH", "")]
    if os.name == "nt":
        try:
            pipes += ["\\\\.\\pipe\\" + name for name in os.listdir("\\\\.\\pipe\\")
                      if re.fullmatch(r"codex-browser-use-[0-9a-f-]{36}", name)]
        except OSError:
            pass
    last_error = "请保持 Codex 桌面应用开启。"
    for pipe in dict.fromkeys(p for p in pipes if p):
        bridge = McpBridge(node, server, pipe, config["caller_thread_id"])
        try:
            bridge.initialize()
            # Validate that the caller is an actual chat in this app instance.
            data = bridge.call("read_thread", {"threadId": config["caller_thread_id"], "turnLimit": 1,
                                               "includeOutputs": False, "maxOutputCharsPerItem": 0})
            if data.get("thread", {}).get("id") != config["caller_thread_id"]:
                raise BridgeError("调用方对话不存在于此 Codex 实例")
            return bridge
        except (BridgeError, UncertainDelivery) as exc:
            last_error = str(exc)
            bridge.close()
    raise RuntimeError("无法连接 Codex 本地工具服务：" + last_error)


def quota_ready(data, limit_id):
    if data.get("ordinaryUsageAllowed") is False:
        return False
    buckets = data.get("rateLimitsByLimitId")
    if isinstance(buckets, dict) and buckets:
        limit = buckets.get(limit_id)
    else:
        limit = data.get("rateLimits")
        if limit and limit.get("limitId") not in (None, limit_id):
            return False
    if not isinstance(limit, dict):
        return False
    if limit.get("rateLimitReachedType") or limit.get("spendControlReached"):
        return False
    if limit.get("individualLimit"):
        return False  # Unknown workspace/user limit: wait rather than assume access.
    seen = False
    for name in ("primary", "secondary"):
        window = limit.get(name)
        if window is None:
            continue
        percent = window.get("usedPercent") if isinstance(window, dict) else None
        if isinstance(percent, bool) or not isinstance(percent, (float, int)):
            return False
        if not math.isfinite(percent) or not 0 <= percent < 100:
            return False
        seen = True
    return seen


def quota_summary(data, limit_id):
    limits = data.get("rateLimitsByLimitId") or {}
    limit = limits.get(limit_id) if limits else data.get("rateLimits")
    parts = []
    for name, label in (("primary", "短周期"), ("secondary", "长周期")):
        window = (limit or {}).get(name)
        if not isinstance(window, dict):
            continue
        reset = window.get("resetsAt")
        try:
            reset_text = datetime.fromtimestamp(reset).astimezone().strftime("%Y-%m-%d %H:%M:%S %z")
        except (ValueError, TypeError, OverflowError, OSError):
            reset_text = "未知"
        parts.append(f"{label}已用 {window.get('usedPercent', '未知')}%，重置 {reset_text}")
    return "；".join(parts) or "额度数据未知"


def is_quota_failure(turn):
    if turn.get("status") not in ("failed", "error") or not turn.get("id"):
        return False
    error = turn.get("error")
    if not error:
        return False
    if isinstance(error, dict):
        # Only structured top-level errors, never chat text or tool output.
        info = error.get("codexErrorInfo", error.get("code", ""))
        compact = re.sub(r"[^a-z]", "", json.dumps(info).lower())
        if any(code in compact for code in ("usagelimitexceeded", "usagelimitreached", "quotalimitexceeded", "quotaexceeded")):
            return True
        text = str(error.get("message", ""))
    elif isinstance(error, str):
        text = error
    else:
        return False
    return bool(re.search(
        r"(?:you.?ve|you have) (?:hit|reached) (?:your|the) usage limit|usage limit (?:reached|exceeded)|"
        r"(?:quota|usage) (?:has been )?exhausted|insufficient[_ ]quota|usage_limit_reached|"
        r"额度(?:已)?(?:用尽|耗尽)|(?:达到|达到了|已达)(?:使用)?(?:额度|用量)上限",
        text, re.I,
    ))


def runtime_active(thread):
    status = thread.get("status")
    return status == "active" or isinstance(status, dict) and status.get("type") == "active"


class Monitor:
    def __init__(self, bridge, config, state_path, stop_path, dry_run=False, now=time.time):
        self.bridge, self.config = bridge, config
        self.state_path, self.stop_path = Path(state_path), Path(stop_path)
        self.dry_run, self.now = dry_run, now
        if self.state_path.exists():
            # Corrupted state must not cause a second send after a restart.
            self.state = json.loads(self.state_path.read_text(encoding="utf-8"))
            if self.state.get("version") != 1 or not isinstance(self.state.get("records"), dict):
                raise RuntimeError("状态文件无效；请先检查 state.json，不能自动重置发送记录。")
        else:
            self.state = {"version": 1, "records": {}}
        for record in self.state["records"].values():
            if record.get("status") == "sending":
                record["status"] = "unknown"
        self.previous_summary = None

    def save(self):
        if not self.dry_run:
            atomic_json(self.state_path, self.state)

    def read_latest(self, thread_id, host_id):
        data = self.bridge.call("read_thread", {
            "threadId": thread_id, "hostId": host_id, "turnLimit": 1,
            "includeOutputs": False, "maxOutputCharsPerItem": 0,
        })
        turns = data.get("turns") or []
        return data.get("thread", {}), turns[0] if turns else {}

    def step(self):
        limits = self.bridge.call("get_usage_limits", {})
        summary = quota_summary(limits, self.config["limit_id"])
        if summary != self.previous_summary:
            LOG.info("%s；可续跑=%s", summary, quota_ready(limits, self.config["limit_id"]))
            self.previous_summary = summary
        account = limits.get("accountId")
        if not account:
            LOG.warning("缺少账号标识，暂不发送 continue。")
            return
        listing = self.bridge.call("list_threads", {"limit": 50})
        candidates = {(t.get("hostId", "local"), t["id"]): t
                      for t in listing.get("pinnedThreads", []) + listing.get("threads", [])
                      if t.get("kind") == "codex" and t.get("id")}
        for tid in self.config["thread_ids"]:
            candidates.setdefault(("local", tid), {"id": tid, "hostId": "local", "kind": "codex"})
        for record in self.state["records"].values():
            if record.get("status") in ("pending", "sending", "unknown"):
                candidates.setdefault((record["host_id"], record["thread_id"]), record)
        resumed = 0
        for (host_id, thread_id), listed in candidates.items():
            if self.stop_path.exists():
                break
            # Quotas come from the local host. Remote/cloud chats need their own watcher.
            if host_id != "local" or thread_id in self.config["exclude_thread_ids"]:
                continue
            if self.config["thread_ids"] and thread_id not in self.config["thread_ids"]:
                continue
            if runtime_active(listed):
                continue
            try:
                thread, turn = self.read_latest(thread_id, host_id)
            except BridgeError as exc:
                LOG.warning("读取对话 %s 失败：%s", thread_id, exc)
                continue
            key = f"{host_id}:{thread_id}"
            old = self.state["records"].get(key)
            if runtime_active(thread) or not is_quota_failure(turn):
                if old and turn.get("id") and old["turn_id"] != turn["id"]:
                    old["status"] = "superseded"
                    self.save()
                continue
            if not old or old["turn_id"] != turn["id"]:
                old = {
                    "thread_id": thread_id, "host_id": host_id, "turn_id": turn["id"],
                    "account_id": account, "status": "pending", "attempts": 0,
                    "first_seen": self.now(), "next_attempt": 0,
                }
                self.state["records"][key] = old
                self.save()
                LOG.info("发现额度中断对话：%s (%s)", thread.get("title", thread_id), thread_id)
            if old["status"] != "pending" or old["account_id"] != account:
                continue
            if old["attempts"] >= self.config["max_send_attempts"] or self.now() < old["next_attempt"]:
                continue
            if resumed >= self.config["max_resumes_per_cycle"]:
                continue
            # Fetch server truth immediately before each send, even after the reset time passes.
            fresh_limits = self.bridge.call("get_usage_limits", {})
            if fresh_limits.get("accountId") != account or not quota_ready(fresh_limits, self.config["limit_id"]):
                continue
            fresh_thread, fresh_turn = self.read_latest(thread_id, host_id)
            if (runtime_active(fresh_thread) or fresh_turn.get("id") != old["turn_id"]
                    or not is_quota_failure(fresh_turn) or self.stop_path.exists()):
                continue
            if self.dry_run:
                LOG.info("[预演] 将向对话 %s 发送 continue（实际未发送）", thread_id)
                resumed += 1
                continue
            old["status"] = "sending"
            old["attempts"] += 1
            old["attempted_at"] = self.now()
            self.save()  # Persist intent BEFORE dispatch, so a crash cannot duplicate the message.
            try:
                self.bridge.call("send_message_to_thread", {
                    "threadId": thread_id, "hostId": host_id, "prompt": "continue",
                })
            except BridgeError as exc:
                old["status"] = "pending"
                old["next_attempt"] = self.now() + self.config["retry_seconds"]
                LOG.warning("发送被拒绝，对话 %s：%s", thread_id, exc)
                self.save()
            except Exception:
                old["status"] = "unknown"
                self.save()
                LOG.error("对话 %s 发送结果不明；为避免重复，需查看对话后人工处理 state.json。", thread_id)
                raise
            else:
                old["status"] = "sent"
                old["sent_at"] = self.now()
                self.save()
                LOG.info("已向原对话 %s 发送 continue", thread_id)
                resumed += 1


def load_config(path):
    config = dict(DEFAULTS)
    if path.exists():
        loaded = json.loads(path.read_text(encoding="utf-8-sig"))
        unknown = set(loaded) - set(DEFAULTS)
        if unknown:
            raise ValueError("未知配置项：" + ", ".join(sorted(unknown)))
        config.update(loaded)
    if not isinstance(config["caller_thread_id"], str) or not config["caller_thread_id"]:
        raise ValueError("caller_thread_id 必须指向本次授权的实际对话。")
    for key in ("poll_seconds", "retry_seconds", "max_resumes_per_cycle", "max_send_attempts"):
        if isinstance(config[key], bool) or not isinstance(config[key], int) or config[key] < 1:
            raise ValueError(key + " 必须为正整数")
    if config["poll_seconds"] < 15:
        raise ValueError("poll_seconds 最小为 15 秒")
    for key in ("thread_ids", "exclude_thread_ids"):
        if not isinstance(config[key], list) or any(not isinstance(t, str) or not t for t in config[key]):
            raise ValueError(key + " 必须为对话 ID 数组")
    for key in ("limit_id", "node_path", "server_path", "pipe_path"):
        if not isinstance(config[key], str):
            raise ValueError(key + " 必须为字符串")
    return config


def main():
    parser = argparse.ArgumentParser(description="监测 Codex 额度，恢复额度中断的本地对话")
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    parser.add_argument("--state-dir", type=Path, default=runtime_directory())
    parser.add_argument("--dry-run", action="store_true", help="只检查，不发送消息、不修改续跑状态")
    parser.add_argument("--once", action="store_true", help="检查一轮后退出")
    args = parser.parse_args()
    args.state_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[
        logging.FileHandler(args.state_dir / "monitor.log", encoding="utf-8"), logging.StreamHandler(),
    ])
    lock, bridge = None, None
    try:
        config = load_config(args.config)
        lock = InstanceLock(args.state_dir / "monitor.lock")
        stop = args.state_dir / "stop.flag"
        stop.unlink(missing_ok=True)
        # Load state once and retain it across connection failures.
        monitor = Monitor(None, config, args.state_dir / "state.json", stop, args.dry_run)
        monitor.save()
        LOG.info("启动监测，间隔 %s 秒，模式=%s", config["poll_seconds"], "只读预演" if args.dry_run else "自动续跑")
        while not stop.exists():
            try:
                if bridge is None:
                    bridge = connect(config)
                    LOG.info("已连接 Codex 桌面工具服务")
                monitor.bridge = bridge
                monitor.step()
            except (BridgeError, UncertainDelivery, RuntimeError, OSError) as exc:
                LOG.warning("本轮暂不可用：%s", exc)
                if bridge:
                    bridge.close()
                    bridge = None
                if args.once:
                    return 1
            if args.once:
                return 0
            deadline = time.monotonic() + config["poll_seconds"]
            while not stop.exists() and time.monotonic() < deadline:
                time.sleep(min(1, max(0, deadline - time.monotonic())))
        LOG.info("收到停止指令，监测已停止。")
        return 0
    except KeyboardInterrupt:
        LOG.info("监测已停止。")
        return 0
    except Exception as exc:
        LOG.error("无法启动：%s", exc)
        return 1
    finally:
        if bridge:
            bridge.close()
        if lock:
            lock.close()


if __name__ == "__main__":
    raise SystemExit(main())
