import copy
from pathlib import Path
import queue
import threading
import time
import unittest
import uuid

from desktop_app import WorkerController
from monitor import DEFAULTS, InstanceLock, atomic_json


class FakeDesktopBridge:
    def __init__(self):
        self.checked = threading.Event()
        self.closed = False

    def call(self, name, arguments):
        if name == 'get_usage_limits':
            return {'accountId': 'account', 'rateLimits': {'limitId': 'codex',
                    'primary': {'usedPercent': 10, 'resetsAt': 1}, 'secondary': None}}
        if name == 'list_threads':
            self.checked.set()
            return {'threads': [], 'pinnedThreads': []}
        raise AssertionError('Unexpected tool: ' + name)

    def close(self):
        self.closed = True


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parent / ('.test-' + uuid.uuid4().hex)
        self.root.mkdir()
        self.config = self.root / 'config.json'
        self.runtime = self.root / 'runtime'
        self.events = queue.Queue()
        self.bridge = FakeDesktopBridge()
        atomic_json(self.config, copy.deepcopy(DEFAULTS))
        self.worker = WorkerController(self.config, self.runtime, self.events,
                                       bridge_factory=lambda config: self.bridge)

    def tearDown(self):
        if self.worker.alive:
            self.worker.stop()
            self.worker.thread.join(3)
        assert self.root.resolve().parent == Path(__file__).resolve().parent
        if self.runtime.exists():
            for file in self.runtime.iterdir():
                file.unlink()
            self.runtime.rmdir()
        for file in self.root.iterdir():
            file.unlink()
        self.root.rmdir()

    def drain(self):
        items = []
        while not self.events.empty():
            items.append(self.events.get_nowait())
        return items

    def test_start_stop_buttons_drive_worker_and_release_lock(self):
        self.assertTrue(self.worker.start())
        self.assertTrue(self.bridge.checked.wait(3))
        self.assertFalse(self.worker.start())
        self.worker.stop()
        self.worker.thread.join(3)
        self.assertFalse(self.worker.alive)
        self.assertTrue(self.bridge.closed)
        events = self.drain()
        self.assertIn(('status', 'running'), events)
        self.assertEqual(events[-1], ('status', 'stopped'))
        lock = InstanceLock(self.runtime / 'monitor.lock')
        lock.close()

    def test_existing_script_lock_prevents_exe_worker(self):
        self.runtime.mkdir()
        lock = InstanceLock(self.runtime / 'monitor.lock')
        try:
            self.worker.start()
            self.worker.thread.join(3)
            self.assertFalse(self.worker.alive)
            events = self.drain()
            self.assertTrue(any(kind == 'error' for kind, data in events))
            self.assertFalse(self.bridge.checked.is_set())
        finally:
            lock.close()

    def test_start_can_be_used_again_after_stop(self):
        self.worker.start()
        self.assertTrue(self.bridge.checked.wait(3))
        self.worker.stop()
        self.worker.thread.join(3)
        self.bridge = FakeDesktopBridge()
        self.worker.start()
        self.assertTrue(self.bridge.checked.wait(3))
        self.worker.stop()
        self.worker.thread.join(3)
        self.assertFalse(self.worker.alive)

    def test_closing_idle_second_window_does_not_stop_running_monitor(self):
        self.runtime.mkdir()
        lock = InstanceLock(self.runtime / 'monitor.lock')
        try:
            self.worker.stop()
            self.assertFalse((self.runtime / 'stop.flag').exists())
        finally:
            lock.close()


if __name__ == '__main__':
    unittest.main()
