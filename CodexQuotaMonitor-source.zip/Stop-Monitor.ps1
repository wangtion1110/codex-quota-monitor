$ErrorActionPreference = 'Stop'
$runtimeDirectory = Join-Path $env:LOCALAPPDATA 'CodexQuotaMonitor\runtime'
New-Item -ItemType Directory -Path $runtimeDirectory -Force | Out-Null
Set-Content -LiteralPath (Join-Path $runtimeDirectory 'stop.flag') -Value 'stop' -Encoding ASCII
Write-Host 'Stop requested. The monitor exits after the current request (normally within 30 seconds).'
