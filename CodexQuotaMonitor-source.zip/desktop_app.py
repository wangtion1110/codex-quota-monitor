"""Small Windows desktop controller for the quota monitor."""
from __future__ import annotations

import argparse
import json
import logging
import os
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk

from monitor import (DEFAULTS, LOG, BridgeError, InstanceLock, Monitor, UncertainDelivery,
                     atomic_json, connect, load_config, quota_ready, quota_summary,
                     runtime_directory)


class QueueLogHandler(logging.Handler):
    def __init__(self, events):
        super().__init__()
        self.events = events
        self.setFormatter(logging.Formatter("%(asctime)s  %(message)s", datefmt="%H:%M:%S"))

    def emit(self, record):
        self.events.put(("log", self.format(record)))


class ReportingBridge:
    def __init__(self, bridge, events, limit_id):
        self.bridge, self.events, self.limit_id = bridge, events, limit_id

    def call(self, name, arguments):
        result = self.bridge.call(name, arguments)
        if name == "get_usage_limits":
            self.events.put(("quota", result))
        return result


class WorkerController:
    def __init__(self, config_path, state_dir, events, bridge_factory=connect, dry_run=False):
        self.config_path, self.state_dir = Path(config_path), Path(state_dir)
        self.events, self.bridge_factory, self.dry_run = events, bridge_factory, dry_run
        self.stop_event = threading.Event()
        self.owns_lock = threading.Event()
        self.thread = None

    @property
    def alive(self):
        return self.thread is not None and self.thread.is_alive()

    def start(self):
        if self.alive:
            return False
        self.stop_event.clear()
        self.events.put(("status", "starting"))
        self.thread = threading.Thread(target=self._run, daemon=True, name="quota-monitor")
        self.thread.start()
        return True

    def stop(self):
        self.stop_event.set()
        if self.owns_lock.is_set():
            self.state_dir.mkdir(parents=True, exist_ok=True)
            (self.state_dir / "stop.flag").write_text("stop", encoding="ascii")
        if self.alive:
            self.events.put(("status", "stopping"))

    def _run(self):
        bridge, lock = None, None
        handler = QueueLogHandler(self.events)
        LOG.addHandler(handler)
        LOG.setLevel(logging.INFO)
        try:
            self.state_dir.mkdir(parents=True, exist_ok=True)
            lock = InstanceLock(self.state_dir / "monitor.lock")
            self.owns_lock.set()
            config = load_config(self.config_path)
            stop = self.state_dir / "stop.flag"
            stop.unlink(missing_ok=True)
            monitor = Monitor(None, config, self.state_dir / "state.json", stop, self.dry_run)
            monitor.save()
            LOG.info("监测已打开，查询间隔 %s 秒。", config["poll_seconds"])
            while not self.stop_event.is_set() and not stop.exists():
                try:
                    if bridge is None:
                        self.events.put(("status", "connecting"))
                        bridge = self.bridge_factory(config)
                        LOG.info("已连接 Codex 桌面应用。")
                    if self.stop_event.is_set() or stop.exists():
                        break
                    monitor.bridge = ReportingBridge(bridge, self.events, config["limit_id"])
                    self.events.put(("status", "running"))
                    monitor.step()
                    self.events.put(("checked", time.strftime("%H:%M:%S")))
                except (BridgeError, UncertainDelivery, RuntimeError, OSError) as exc:
                    LOG.warning("等待下次重试：%s", exc)
                    self.events.put(("status", "waiting"))
                    if bridge:
                        bridge.close()
                        bridge = None
                deadline = time.monotonic() + config["poll_seconds"]
                while not stop.exists() and time.monotonic() < deadline:
                    if self.stop_event.wait(min(1, max(0, deadline - time.monotonic()))):
                        break
            LOG.info("监测已关闭。")
        except Exception as exc:
            LOG.error("无法打开监测：%s", exc)
            self.events.put(("error", str(exc)))
        finally:
            try:
                if bridge:
                    bridge.close()
            finally:
                if lock:
                    lock.close()
                self.owns_lock.clear()
                LOG.removeHandler(handler)
                self.events.put(("status", "stopped"))


class DesktopApp:
    def __init__(self, root, data_dir, controller=None, dry_run=False):
        self.root, self.data_dir = root, Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.runtime = self.data_dir / "runtime"
        self.runtime.mkdir(parents=True, exist_ok=True)
        self.config_path = self.data_dir / "config.json"
        if not self.config_path.exists():
            atomic_json(self.config_path, DEFAULTS)
        config = load_config(self.config_path)
        self.events = queue.Queue()
        self.controller = controller or WorkerController(self.config_path, self.runtime, self.events, dry_run=dry_run)
        if controller:
            controller.events = self.events
        self.closing = False
        self.active = False
        self.limit_id = config["limit_id"]
        self.status_text = tk.StringVar(value="已关闭")
        self.description = tk.StringVar(value="点击打开，开始等待额度恢复。")
        self.interval = tk.StringVar(value=str(config["poll_seconds"]))
        self.checked_text = tk.StringVar(value="尚未检查")
        self.quota_text = {}
        self.reset_text = {}
        self.progress = {}
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.after(150, self.process_events)

    def _build(self):
        root = self.root
        root.title("Codex 自动续跑")
        root.geometry("720x620")
        root.minsize(660, 580)
        root.configure(bg="#f3f6fa")
        root.option_add("*Font", ("Microsoft YaHei UI", 10))
        style = ttk.Style(root)
        style.theme_use("clam")
        style.configure("Quota.Horizontal.TProgressbar", troughcolor="#e7edf3", background="#238677",
                        bordercolor="#e7edf3", lightcolor="#238677", darkcolor="#238677", thickness=8)
        body = tk.Frame(root, bg="#f3f6fa", padx=28, pady=22)
        body.pack(fill="both", expand=True)
        tk.Label(body, text="Codex 自动续跑", font=("Microsoft YaHei UI", 22, "bold"),
                 bg="#f3f6fa", fg="#152c45", anchor="w").pack(fill="x")
        tk.Label(body, text="额度恢复后，自动继续因额度中断的对话", bg="#f3f6fa", fg="#60758b",
                 anchor="w").pack(fill="x", pady=(4, 18))

        status = tk.Frame(body, bg="white", padx=18, pady=14)
        status.pack(fill="x")
        self.status_label = tk.Label(status, textvariable=self.status_text, bg="white", fg="#60758b",
                                     font=("Microsoft YaHei UI", 14, "bold"), anchor="w")
        self.status_label.pack(fill="x")
        tk.Label(status, textvariable=self.description, bg="white", fg="#60758b", anchor="w").pack(fill="x", pady=(5, 0))

        cards = tk.Frame(body, bg="#f3f6fa")
        cards.pack(fill="x", pady=14)
        cards.columnconfigure(0, weight=1)
        cards.columnconfigure(1, weight=1)
        for column, (name, label) in enumerate((("primary", "短周期额度"), ("secondary", "长周期额度"))):
            card = tk.Frame(cards, bg="white", padx=16, pady=12)
            card.grid(row=0, column=column, sticky="nsew", padx=(0, 7) if column == 0 else (7, 0))
            tk.Label(card, text=label, bg="white", fg="#60758b", anchor="w").pack(fill="x")
            value = self.quota_text[name] = tk.StringVar(value="等待查询")
            tk.Label(card, textvariable=value, bg="white", fg="#152c45", anchor="w",
                     font=("Microsoft YaHei UI", 17, "bold")).pack(fill="x", pady=(3, 7))
            progress = self.progress[name] = ttk.Progressbar(card, style="Quota.Horizontal.TProgressbar", maximum=100)
            progress.pack(fill="x")
            reset = self.reset_text[name] = tk.StringVar(value="重置时间：—")
            tk.Label(card, textvariable=reset, bg="white", fg="#60758b", anchor="w",
                     font=("Microsoft YaHei UI", 9)).pack(fill="x", pady=(7, 0))

        controls = tk.Frame(body, bg="#f3f6fa")
        controls.pack(fill="x", pady=(0, 16))
        self.start_button = tk.Button(controls, text="打开监测", command=self.start, bg="#238677", fg="white",
                                      activebackground="#1c6c61", activeforeground="white", relief="flat", bd=0,
                                      padx=28, pady=11, cursor="hand2", font=("Microsoft YaHei UI", 11, "bold"))
        self.start_button.pack(side="left", padx=(0, 10))
        self.stop_button = tk.Button(controls, text="关闭监测", command=self.stop, bg="#e1e8ef", fg="#34495e",
                                     relief="flat", bd=0, padx=28, pady=11, state="disabled", cursor="hand2",
                                     font=("Microsoft YaHei UI", 11, "bold"))
        self.stop_button.pack(side="left")
        interval_frame = tk.Frame(controls, bg="#f3f6fa")
        interval_frame.pack(side="right")
        tk.Label(interval_frame, text="每", bg="#f3f6fa", fg="#60758b").pack(side="left")
        self.interval_entry = tk.Spinbox(interval_frame, from_=15, to=3600, increment=15,
                                        textvariable=self.interval, width=5, relief="flat", bd=3)
        self.interval_entry.pack(side="left", padx=5)
        tk.Label(interval_frame, text="秒检查", bg="#f3f6fa", fg="#60758b").pack(side="left")

        log_header = tk.Frame(body, bg="#f3f6fa")
        log_header.pack(fill="x", pady=(0, 5))
        tk.Label(log_header, text="运行记录", font=("Microsoft YaHei UI", 10, "bold"),
                 bg="#f3f6fa", fg="#34495e").pack(side="left")
        tk.Label(log_header, textvariable=self.checked_text, bg="#f3f6fa", fg="#60758b").pack(side="right")
        self.log_text = tk.Text(body, height=8, wrap="word", state="disabled", bg="white", fg="#34495e",
                                relief="flat", padx=12, pady=10, font=("Microsoft YaHei UI", 9))
        self.log_text.pack(fill="both", expand=True)
        footer = tk.Frame(body, bg="#f3f6fa")
        footer.pack(fill="x", pady=(11, 0))
        tk.Label(footer, text="请保持 Codex 开启；关闭本窗口也会停止监测。", bg="#f3f6fa", fg="#60758b",
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        tk.Button(footer, text="查看日志", command=self.open_logs, bg="#f3f6fa", fg="#238677", relief="flat",
                  bd=0, cursor="hand2").pack(side="right")
        self.append_log("程序已就绪。默认关闭，点击“打开监测”后开始自动续跑。")

    def append_log(self, text):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        line_count = int(self.log_text.index("end-1c").split(".")[0])
        if line_count > 200:
            self.log_text.delete("1.0", f"{line_count - 200}.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def start(self):
        if self.active or self.closing:
            return
        try:
            interval = int(self.interval.get())
            if interval < 15:
                raise ValueError("查询间隔至少为 15 秒")
            config = load_config(self.config_path)
            config["poll_seconds"] = interval
            atomic_json(self.config_path, config)
            self.limit_id = config["limit_id"]
            if self.controller.start():
                self.active = True
                self.set_status("starting")
        except (OSError, ValueError) as exc:
            messagebox.showerror("无法打开监测", str(exc), parent=self.root)

    def stop(self):
        if self.active:
            self.controller.stop()
            self.set_status("stopping")

    def set_status(self, status):
        messages = {
            "stopped": ("已关闭", "点击打开，开始等待额度恢复。", "#60758b"),
            "starting": ("正在打开", "正在检查配置与连接…", "#60758b"),
            "connecting": ("正在连接", "正在连接 Codex 桌面应用…", "#b1841b"),
            "running": ("监测中", "额度恢复后会向中断的原对话发送 continue。", "#238677"),
            "waiting": ("等待连接", "连接暂不可用，稍后自动重试。请保持 Codex 开启。", "#b1841b"),
            "stopping": ("正在关闭", "完成当前请求后停止，不再提交新的续跑消息。", "#60758b"),
        }
        title, description, color = messages[status]
        if self.closing and status != "stopped":
            title, description = "正在退出", "等待当前请求结束…"
        self.status_text.set(title)
        self.description.set(description)
        self.status_label.configure(fg=color)
        running = status != "stopped"
        self.active = running
        self.start_button.configure(state="disabled" if running or self.closing else "normal")
        self.stop_button.configure(state="normal" if running and status != "stopping" and not self.closing else "disabled")
        self.interval_entry.configure(state="disabled" if running else "normal")

    def show_quota(self, data):
        buckets = data.get("rateLimitsByLimitId") or {}
        bucket = buckets.get(self.limit_id) if buckets else data.get("rateLimits")
        for name in ("primary", "secondary"):
            window = (bucket or {}).get(name)
            percent = window.get("usedPercent") if isinstance(window, dict) else None
            if not isinstance(percent, (int, float)):
                self.quota_text[name].set("暂不可用")
                continue
            remaining = max(0, min(100, 100 - percent))
            self.quota_text[name].set(f"剩余 {remaining:g}%")
            self.progress[name]["value"] = remaining
            reset = window.get("resetsAt")
            try:
                reset_string = time.strftime("%m-%d %H:%M", time.localtime(reset)) if reset is not None else "未知"
            except (ValueError, OverflowError, OSError):
                reset_string = "未知"
            self.reset_text[name].set("重置时间：" + reset_string)
        self.description.set("额度可用，正在检查中断对话。" if quota_ready(data, self.limit_id)
                             else "额度尚未恢复，正在等待下次检查。")

    def process_events(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == "log":
                    self.append_log(data)
                elif kind == "status":
                    self.set_status(data)
                elif kind == "quota":
                    self.show_quota(data)
                elif kind == "checked":
                    self.checked_text.set("上次检查 " + data)
                elif kind == "error":
                    self.append_log("错误：" + data)
        except queue.Empty:
            pass
        if self.closing and not self.controller.alive:
            self.root.destroy()
            return
        self.root.after(150, self.process_events)

    def open_logs(self):
        os.startfile(str(self.runtime))

    def close(self):
        self.closing = True
        self.controller.stop()
        if not self.controller.alive:
            self.root.destroy()
        else:
            self.set_status("stopping")


def gui_self_test(data_dir):
    class FakeController:
        alive = False

        def start(self):
            self.alive = True
            self.events.put(("status", "running"))
            return True

        def stop(self):
            self.alive = False
            self.events.put(("status", "stopped"))

    root = tk.Tk()
    root.withdraw()
    try:
        app = DesktopApp(root, data_dir, controller=FakeController())
        assert app.start_button["text"] == "打开监测"
        assert app.stop_button["text"] == "关闭监测"
        assert app.start_button["state"] == "normal"
        app.start()
        app.process_events()
        assert app.status_text.get() == "监测中"
        assert app.start_button["state"] == "disabled"
        assert app.stop_button["state"] == "normal"
        app.show_quota({"rateLimits": {"limitId": "codex", "primary": {"usedPercent": 25, "resetsAt": 1}, "secondary": None}})
        assert app.quota_text["primary"].get() == "剩余 75%"
        app.stop()
        app.process_events()
        assert app.status_text.get() == "已关闭"
        assert app.start_button["state"] == "normal"
        root.update_idletasks()
        return {"ok": True, "buttons": [app.start_button["text"], app.stop_button["text"]],
                "start_stop": "passed", "quota_display": "passed", "default": "off"}
    finally:
        root.destroy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=runtime_directory().parent)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--check", action="store_true", help="Read-only packaged bridge test")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    report = {}
    try:
        if args.self_test:
            report = gui_self_test(args.data_dir)
        elif args.check:
            bridge = connect(load_config(args.data_dir / "config.json"))
            try:
                data = bridge.call("get_usage_limits", {})
                report = {"ok": True, "summary": quota_summary(data, "codex"), "read_only": True}
            finally:
                bridge.close()
        else:
            args.data_dir.mkdir(parents=True, exist_ok=True)
            (args.data_dir / "runtime").mkdir(parents=True, exist_ok=True)
            logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", handlers=[
                logging.FileHandler(args.data_dir / "runtime/monitor.log", encoding="utf-8"),
            ])
            root = tk.Tk()
            app = DesktopApp(root, args.data_dir, dry_run=args.dry_run)
            root.mainloop()
            return 0
    except Exception as exc:
        report = {"ok": False, "error": str(exc)}
        if not args.self_test and not args.check:
            messagebox.showerror("无法启动", str(exc))
    if args.report:
        atomic_json(args.report, report)
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
