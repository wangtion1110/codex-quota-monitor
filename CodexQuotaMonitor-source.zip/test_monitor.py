import copy
import json
from pathlib import Path
import unittest
import uuid

from monitor import (BridgeError, DEFAULTS, InstanceLock, Monitor, UncertainDelivery,
                     atomic_json, is_quota_failure, quota_ready)


def limits(percent=20, weekly=30, account="account-a"):
    return {
        "accountId": account, "ordinaryUsageAllowed": True,
        "rateLimitsByLimitId": {"codex": {
            "limitId": "codex", "primary": {"usedPercent": percent, "resetsAt": 1},
            "secondary": {"usedPercent": weekly, "resetsAt": 1},
            "rateLimitReachedType": None,
        }},
    }


def failed(turn_id="turn-1"):
    return {"id": turn_id, "status": "failed", "error": {
        "codexErrorInfo": "usageLimitExceeded", "message": "You've hit your usage limit.",
    }}


class FakeBridge:
    def __init__(self):
        self.quota = limits()
        self.thread = {"id": "chat-a", "kind": "codex", "hostId": "local",
                       "status": {"type": "idle"}, "title": "Test"}
        self.turn = failed()
        self.sent = []
        self.send_error = None
        self.read_hook = None
        self.quota_hook = None
        self.read_count = 0
        self.quota_count = 0
        self.listed = None

    def call(self, name, arguments):
        if name == "get_usage_limits":
            self.quota_count += 1
            if self.quota_hook:
                self.quota_hook(self.quota_count)
            return copy.deepcopy(self.quota)
        if name == "list_threads":
            return {"threads": copy.deepcopy(self.listed if self.listed is not None else [self.thread]),
                    "pinnedThreads": []}
        if name == "read_thread":
            self.read_count += 1
            if self.read_hook:
                self.read_hook(self.read_count)
            return {"thread": copy.deepcopy(self.thread), "turns": [copy.deepcopy(self.turn)]}
        if name == "send_message_to_thread":
            self.sent.append(copy.deepcopy(arguments))
            if self.send_error:
                raise self.send_error
            return {"status": "queued"}
        raise AssertionError(name)


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parent / (".test-" + uuid.uuid4().hex)
        self.root.mkdir()
        self.state = self.root / "state.json"
        self.stop = self.root / "stop.flag"
        self.config = copy.deepcopy(DEFAULTS)
        self.fake = FakeBridge()
        self.clock = 1000
        self.monitor = Monitor(self.fake, self.config, self.state, self.stop, now=lambda: self.clock)

    def tearDown(self):
        assert self.root.resolve().parent == Path(__file__).resolve().parent
        for file in self.root.iterdir():
            file.unlink()
        self.root.rmdir()

    def record(self):
        return self.monitor.state["records"]["local:chat-a"]

    def test_exhausted_then_recovered_sends_exact_continue(self):
        self.fake.quota = limits(100)
        self.monitor.step()
        self.assertEqual(self.fake.sent, [])
        self.assertEqual(self.record()["status"], "pending")
        self.fake.quota = limits(0)
        self.monitor.step()
        self.assertEqual(self.fake.sent, [{"threadId": "chat-a", "hostId": "local", "prompt": "continue"}])

    def test_reset_timestamp_alone_does_not_prove_recovery(self):
        self.fake.quota = limits(100)  # resetsAt=1 is already in the past.
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_weekly_limit_blocks_even_if_short_limit_recovers(self):
        self.fake.quota = limits(0, 100)
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_no_duplicate_after_repeat_and_process_restart(self):
        self.monitor.step()
        self.monitor.step()
        restarted = Monitor(self.fake, self.config, self.state, self.stop)
        restarted.step()
        self.assertEqual(len(self.fake.sent), 1)

    def test_completed_cancelled_or_nonquota_errors_are_ignored(self):
        for turn in (
            {"id": "t", "status": "completed", "error": None},
            {"id": "t", "status": "interrupted", "error": failed()["error"]},
            {"id": "t", "status": "failed", "error": {"message": "HTTP 429: too many requests"}},
            {"id": "t", "status": "failed", "error": {"message": "network timeout"},
             "items": [{"text": "You've hit your usage limit"}]},
        ):
            with self.subTest(turn=turn):
                self.fake.turn = turn
                self.monitor.step()
                self.assertFalse(self.fake.sent)

    def test_active_chat_is_skipped(self):
        self.fake.thread["status"] = {"type": "active", "activeFlags": ["waitingOnApproval"]}
        self.monitor.step()
        self.assertEqual(self.fake.read_count, 0)
        self.assertFalse(self.fake.sent)

    def test_human_continues_before_dispatch(self):
        def hook(count):
            if count == 2:
                self.fake.turn = {"id": "turn-human", "status": "inProgress", "error": None}
        self.fake.read_hook = hook
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_quota_depletes_before_dispatch(self):
        self.fake.quota_hook = lambda count: setattr(self.fake, "quota", limits(100)) if count == 2 else None
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_stop_before_dispatch(self):
        self.fake.read_hook = lambda count: self.stop.touch() if count == 2 else None
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_timeout_marks_unknown_and_never_retries(self):
        self.fake.send_error = UncertainDelivery("lost acknowledgement")
        with self.assertRaises(UncertainDelivery):
            self.monitor.step()
        self.assertEqual(self.record()["status"], "unknown")
        self.fake.send_error = None
        restarted = Monitor(self.fake, self.config, self.state, self.stop)
        restarted.step()
        self.assertEqual(len(self.fake.sent), 1)

    def test_crash_after_intent_does_not_retry(self):
        self.fake.quota = limits(100)
        self.monitor.step()
        self.record()["status"] = "sending"
        self.monitor.save()
        self.fake.quota = limits(0)
        restarted = Monitor(self.fake, self.config, self.state, self.stop)
        restarted.step()
        self.assertFalse(self.fake.sent)
        self.assertEqual(restarted.state["records"]["local:chat-a"]["status"], "unknown")

    def test_definite_rejection_has_backoff_and_attempt_limit(self):
        self.fake.send_error = BridgeError("not accepted")
        self.monitor.step()
        self.monitor.step()
        self.assertEqual(len(self.fake.sent), 1)
        self.clock += 301
        self.monitor.step()
        self.clock += 301
        self.monitor.step()
        self.clock += 301
        self.monitor.step()
        self.assertEqual(len(self.fake.sent), 3)

    def test_new_quota_failed_turn_can_resume_again(self):
        self.monitor.step()
        self.fake.turn = failed("turn-2")
        self.monitor.step()
        self.assertEqual(len(self.fake.sent), 2)

    def test_old_account_queue_is_not_sent_under_new_account(self):
        self.fake.quota = limits(100)
        self.monitor.step()
        self.fake.quota = limits(0, account="account-b")
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_dry_run_never_sends_or_persists_state(self):
        dry_run = Monitor(self.fake, self.config, self.state, self.stop, dry_run=True)
        dry_run.step()
        self.assertFalse(self.fake.sent)
        self.assertFalse(self.state.exists())

    def test_explicit_old_thread_outside_sidebar_list(self):
        self.config["thread_ids"] = ["chat-a"]
        self.fake.listed = []
        self.monitor.step()
        self.assertEqual(len(self.fake.sent), 1)

    def test_excluded_chat_and_remote_host_are_skipped(self):
        self.config["exclude_thread_ids"] = ["chat-a"]
        self.monitor.step()
        self.assertFalse(self.fake.sent)
        self.config["exclude_thread_ids"] = []
        self.fake.thread["hostId"] = "remote"
        self.monitor.step()
        self.assertFalse(self.fake.sent)

    def test_corrupt_state_fails_closed(self):
        self.state.write_text("broken", encoding="utf-8")
        with self.assertRaises(ValueError):
            Monitor(self.fake, self.config, self.state, self.stop)

    def test_single_instance_lock(self):
        lock = InstanceLock(self.root / "monitor.lock")
        try:
            with self.assertRaises(RuntimeError):
                InstanceLock(self.root / "monitor.lock")
        finally:
            lock.close()
        new_lock = InstanceLock(self.root / "monitor.lock")
        new_lock.close()


class ClassifierTests(unittest.TestCase):
    def test_missing_invalid_and_other_bucket_data_block(self):
        for data in ({}, {"rateLimits": {"limitId": "other", "primary": {"usedPercent": 0}}},
                     {"rateLimitsByLimitId": {"other": {"primary": {"usedPercent": 0}}}},
                     limits(None), limits(float("nan")), limits(-1), limits(True)):
            with self.subTest(data=data):
                self.assertFalse(quota_ready(data, "codex"))

    def test_global_or_spend_control_blocks(self):
        data = limits()
        data["ordinaryUsageAllowed"] = False
        self.assertFalse(quota_ready(data, "codex"))
        data = limits()
        data["rateLimitsByLimitId"]["codex"]["spendControlReached"] = True
        self.assertFalse(quota_ready(data, "codex"))

    def test_supported_structured_and_localized_errors(self):
        for error in ({"codexErrorInfo": {"UsageLimitExceeded": {}}},
                      {"message": "Usage limit reached. Try again later."},
                      {"message": "额度已耗尽，请等待更新。"}):
            self.assertTrue(is_quota_failure({"id": "t", "status": "failed", "error": error}))


if __name__ == "__main__":
    unittest.main()
