$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$env:PYTHONPATH = Join-Path $PSScriptRoot '.build-tools'
$env:PYINSTALLER_CONFIG_DIR = Join-Path $PSScriptRoot '.build-cache'
python -m PyInstaller --noconfirm --onefile --windowed --noupx --name CodexQuotaMonitor --version-file version_info.txt --distpath dist --workpath build desktop_app.py
if ($LASTEXITCODE -ne 0) { throw 'EXE build failed.' }
